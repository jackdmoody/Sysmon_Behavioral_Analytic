# Data directory
#
# Place your data files here. Supported formats:
#
# --- Sysmon CSV (from your SIEM or Sysmon direct export) ---
#   sysmon.csv  (or any name — pass via --data-path)
#
# --- DARPA Transparent Computing ---
#   darpa/cadets/        ← extract CADETS E3 .json.gz files here
#   darpa/theia/         ← extract THEIA E3 .json.gz files here
#   darpa/fivedirections/
#   darpa/trace/
#
#   Download: https://github.com/darpa-i2o/Transparent-Computing
#   (E3 engagement data is hosted on Google Drive — see README.md)
#
# Raw data files are excluded from git via .gitignore.
